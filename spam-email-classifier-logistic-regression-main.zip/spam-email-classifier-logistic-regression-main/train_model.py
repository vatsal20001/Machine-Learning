import pandas as pd
import pickle
from sklearn.model_selection import KFold, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder

# Load dataset
df = pd.read_csv("Spam_Not_Spam/spam.csv", encoding='latin-1')
#  Sirf required columns lo
df = df[['v1', 'v2']]

# Rename columns
df.columns = ['label', 'email']

# Encode labels 
le = LabelEncoder()
y = le.fit_transform(df['label'])

# Text vectorization
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['email'])

# Model
model = LogisticRegression(max_iter=1000)

# K-Fold Cross Validation
kf = KFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=kf)

print("Accuracy per fold:", scores)
print("Mean Accuracy:", scores.mean())

# Final training
model.fit(X, y)

# Save files
with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("vectorizer.pkl", "wb") as f:
    pickle.dump(vectorizer, f)

with open("label_encoder.pkl", "wb") as f:
    pickle.dump(le, f)

print("✅ Model saved successfully!")