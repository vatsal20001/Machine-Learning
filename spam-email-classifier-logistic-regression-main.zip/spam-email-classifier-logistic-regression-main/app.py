from flask import Flask, render_template, request
import pickle
app = Flask(__name__)

# Load model
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    email = request.form['email']
    vec = vectorizer.transform([email])
    result = model.predict(vec)

    if result[0] == 1:
        prediction = "🚫 SPAM"
    else:
        prediction = "✅ NOT SPAM"

    return render_template('index.html', prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)