import pandas as pd
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn.svm import SVC

# Load dataset
df = pd.read_csv("spam.csv", encoding='latin-1')

# Select useful columns
df = df[['v1', 'v2']]
df.columns = ['label', 'email']

# Encode labels
le = LabelEncoder()
y = le.fit_transform(df['label'])

# Vectorize text
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['email'])

# Train SVM model
model = SVC(kernel='rbf', probability=True)
model.fit(X, y)

# Save files
pickle.dump(model, open("model.pkl", "wb"))
pickle.dump(vectorizer, open("vectorizer.pkl", "wb"))
pickle.dump(le, open("label_encoder.pkl", "wb"))

print("✅ Model trained and saved")