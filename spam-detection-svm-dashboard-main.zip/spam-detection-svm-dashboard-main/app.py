
from flask import Flask, render_template, request
import pickle
import os
app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

model = pickle.load(open(os.path.join(BASE_DIR, "model.pkl"), "rb"))
vectorizer = pickle.load(open(os.path.join(BASE_DIR, "vectorizer.pkl"), "rb"))
le = pickle.load(open(os.path.join(BASE_DIR, "label_encoder.pkl"), "rb"))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    email = request.form['email']
    vec = vectorizer.transform([email])
    pred = model.predict(vec)
    prob = model.predict_proba(vec)
    label = le.inverse_transform(pred)[0]
    confidence = round(max(prob[0]) * 100, 2)
    if label == "spam":
        result = "🚫 SPAM"
    else:
        result = "✅ NOT SPAM"

    return render_template('index.html',
                           prediction=result,
                           confidence=confidence,
                           email=email)

if __name__ == "__main__":
    app.run(debug=True)